import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:stutu/common.dart';

class EditProfile extends StatefulWidget {
  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController ageController = TextEditingController();

  String selectedGender = gn;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    usernameController.text = name;
    emailController.text = id;
    ageController.text = ag;
  }

  Future<void> updateProfile() async {
    setState(() {
      isLoading = true;
    });

    final response = await http.post(
      Uri.parse(ip+'editprof.php'), // Replace with actual API URL
      body: {
        'email': emailController.text,
        'gender': selectedGender,
        'age': ageController.text,
      },
    );

    setState(() {
      isLoading = false;
    });

    final responseData = json.decode(response.body);
    if (responseData.containsKey('success')) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(responseData['success']), backgroundColor: Colors.green),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(responseData['error']), backgroundColor: Colors.red),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFBF5E6),
      appBar: AppBar(
        backgroundColor: const Color(0xFFFBF5E6),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 10),
            Center(
              child: CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey[300],
                backgroundImage: AssetImage('assets/prof.png'),
              ),
            ),
            const SizedBox(height: 10),
            _buildReadOnlyTextField(usernameController, "Username"),
            _buildReadOnlyTextField(emailController, "Email"),
            _buildGenderDropdown(),
            _buildTextField(ageController, "Age"),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: isLoading ? null : updateProfile,
              icon: isLoading ? CircularProgressIndicator() : Icon(Icons.upload_outlined, color: Colors.white),
              label: Text("Update Details", style: TextStyle(color: Colors.white, fontSize: 16)),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1E2A47),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 12),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hintText) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: TextField(
        controller: controller,
        decoration: InputDecoration(
          hintText: hintText,
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  Widget _buildReadOnlyTextField(TextEditingController controller, String label) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: TextField(
        controller: controller,
        readOnly: true,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: Colors.blue[50],
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  Widget _buildGenderDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: DropdownButtonFormField<String>(
        value: selectedGender,
        onChanged: (newValue) => setState(() => selectedGender = newValue!),
        items: ["Male", "Female"].map((gender) => DropdownMenuItem(value: gender, child: Text(gender))).toList(),
        decoration: InputDecoration(
          labelText: "Gender",
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
        ),
      ),
    );
  }
}