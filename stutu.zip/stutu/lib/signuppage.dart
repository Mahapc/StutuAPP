import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:stutu/tutorsign.dart';
import 'common.dart';
import 'loginpage.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});

  @override
  _SignupPageState createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  String _selectedRole = "STUDENT"; // Default selection
  String _selectedGender = "Male"; // Default gender selection
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController experienceController = TextEditingController(); // Added experience field
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  Future<void> _signUp() async {
    String name = nameController.text.trim();
    String email = emailController.text.trim();
    String age = ageController.text.trim();
    String experience = experienceController.text.trim();
    String password = passwordController.text.trim();
    String confirmPassword = confirmPasswordController.text.trim();

    if (name.isEmpty || email.isEmpty || age.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      _showMessage("All fields are required.");
      return;
    }

    if (password != confirmPassword) {
      _showMessage("Passwords do not match.");
      return;
    }

    String apiUrl = _selectedRole == "STUDENT"
        ? "student_signup.php"
        : "tutor_signup.php";

    Map<String, String> requestBody = {
      "name": name,
      "email": email,
      "age": age,
      "gender": _selectedGender,
      "password": password,
    };

    if (_selectedRole == "TUTOR") {
      requestBody["experience"] = experience;
    }

    try {
      var response = await http.post(
        Uri.parse(ip+apiUrl),
        body: requestBody,
      );

      var data = jsonDecode(response.body);
      print(data);

      if(data.containsKey("error") && data["error"]=="Email already exists"){
        _showMessage(data["error"]);
      }
      else if (data.containsKey("success")) {
        _showMessage("Signup successful!");
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => LoginPage()),
        );
      } else {
        _showMessage(data["message"]);
      }
    } catch (e) {
        print(e);
      _showMessage("Error signing up. Please try again.");
    }
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9E7),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            children: [
              const SizedBox(height: 30),
              const Text(
                "Join StuTu!!",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Color(0xFF1A2D56)),
              ),
              const SizedBox(height: 5),
              const Text(
                "Start your learning journey",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Color(0xFF1A2D56)),
              ),
              const SizedBox(height: 15),
              Image.asset(
                'assets/stud.png',
                height: 130,
                fit: BoxFit.cover,
              ),
              const SizedBox(height: 15),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _roleButton("STUDENT"),
                  const SizedBox(width: 10),
                  _roleButton("TUTOR"),
                ],
              ),
              const SizedBox(height: 25),
              _textField("Enter your name", nameController),
              const SizedBox(height: 20),
              _textField("Enter your email", emailController),
              const SizedBox(height: 20),
              _textField("Enter your age", ageController, isNumber: true),
              const SizedBox(height: 20),
              _genderDropdown(),
              if (_selectedRole == "TUTOR") ...[
                const SizedBox(height: 20),
                _textField("Enter your experience", experienceController, isNumber: true),
              ],
              const SizedBox(height: 20),
              _textField("Enter your password", passwordController, isPassword: true),
              const SizedBox(height: 20),
              _textField("Confirm your password", confirmPasswordController, isPassword: true),
              const SizedBox(height: 20),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1A2D56),
                  padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 100),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: _signUp,
                child: const Text("SIGN UP", style: TextStyle(color: Colors.white, fontSize: 16)),
              ),
              const SizedBox(height: 40),
              Image.asset(
                'assets/logo.png',
                height: 40,
                fit: BoxFit.cover,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _roleButton(String role) {
    bool isSelected = _selectedRole == role;
    return GestureDetector(
      onTap: () {
        setState(() {
          _selectedRole = role;
        });
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 30),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF1A2D56) : Colors.black,
          borderRadius: BorderRadius.circular(5),
        ),
        child: Text(
          role,
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  Widget _textField(String hint, TextEditingController controller, {bool isPassword = false, bool isNumber = false}) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      decoration: InputDecoration(
        hintText: hint,
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide.none,
        ),
        suffixIcon: isPassword ? const Icon(Icons.visibility_off) : null,
      ),
    );
  }

  Widget _genderDropdown() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 0),
      child: DropdownButtonFormField<String>(
        value: _selectedGender,
        onChanged: (newValue) {
          setState(() {
            _selectedGender = newValue!;
          });
        },
        items: ["Male", "Female"]
            .map((gender) => DropdownMenuItem(value: gender, child: Text(gender)))
            .toList(),
        decoration: InputDecoration(
          labelText: "Gender",
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}
