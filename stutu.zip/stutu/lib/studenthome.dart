import 'package:flutter/material.dart';
import 'package:stutu/physicspage.dart';

import 'biologypage.dart';
import 'chemistrypage.dart';
import 'customdrawer.dart';

class StudentHomePage extends StatelessWidget {

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: const Color(0xFFFBF5E6), // Light Cream Background
      appBar: AppBar(
        backgroundColor: const Color(0xFF6C757D), // Dark Gray
        title: const Text(
          "StuTu....",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        leading: IconButton(
          icon: const Icon(Icons.menu, color: Colors.white),
          onPressed: () {
            _scaffoldKey.currentState?.openDrawer();
          },
        ),
      ),
      drawer: CustomDrawer(), // Custom Sliding Drawer
      body: Stack(
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              const SizedBox(height: 20),
              const Center(
                child: Text(
                  "Welcome Back...",
                  style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black),
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 10),
              Center(
                child: Image.asset(
                  'assets/grad.png', // Add your graduation image in assets
                  height: 230,
                ),
              ),
              const SizedBox(height: 50),
              const Text(
                "Explore Courses",
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
              ),
              const SizedBox(height: 5),
              const Text(
                "Find the prefect for you",
                style: TextStyle(fontSize: 14, color: Colors.black),
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _subjectButton(context,"Physics"),
                  const SizedBox(width: 20),
                  _subjectButton(context,"Chemistry"),
                ],
              ),
              const SizedBox(height: 15),
              _subjectButton(context,"Biology"),
            ],
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: Image.asset(
                'assets/logo.png', // Add your bottom logo in assets
                height: 50,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _subjectButton(BuildContext context, String title) {
    return GestureDetector(
      onTap: () {
        if (title == "Physics") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PhysicsPage()),
          );
        } else if (title == "Chemistry") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) =>  ChemistryPage()),
          );
        } else if (title == "Biology") {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => BiologyPage()),
          );
        }
      },
      child: Container(
        width: 120,
        height: 45,
        decoration: BoxDecoration(
          color: const Color(0xFF1E2A47),
          borderRadius: BorderRadius.circular(8),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.2), blurRadius: 4, offset: const Offset(2, 2)),
          ],
        ),
        alignment: Alignment.center,
        child: Text(
          title,
          style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }
}
