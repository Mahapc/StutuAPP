import 'package:flutter/material.dart';

class TutorSignPage extends StatefulWidget {
  const TutorSignPage({super.key});

  @override
  State<TutorSignPage> createState() => _TutorSignPageState();
}

class _TutorSignPageState extends State<TutorSignPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController experienceController = TextEditingController();

  String selectedTutorType = "Experienced Tutor"; // Default selection

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFFEF9E7), // Soft cream background
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 30),

            // Title
            const Text(
              "Define Your Expertise",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
            const SizedBox(height: 5),

            // Subtitle
            const Text(
              "Help Us To Understand Your Strength's",
              style: TextStyle(
                fontSize: 14,
                color: Colors.black54,
              ),
            ),
            const SizedBox(height: 20),

            // Name Input Field
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: nameController,
                decoration: InputDecoration(
                  hintText: "Enter your name",
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Tutor Selection (Radio Buttons)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Experienced Tutor Button
                GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedTutorType = "Experienced Tutor";
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 18),
                    decoration: BoxDecoration(
                      color: selectedTutorType == "Experienced Tutor"
                          ? const Color(0xFF1A2D56) // Selected color (Dark Blue)
                          : Colors.white, // Unselected color
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.black),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          offset: const Offset(2, 2),
                          blurRadius: 3,
                        ),
                      ],
                    ),
                    child: Text(
                      "EXPERIENCED TUTOR",
                      style: TextStyle(
                        color: selectedTutorType == "Experienced Tutor"
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 15),

                // New Tutor Button
                GestureDetector(
                  onTap: () {
                    setState(() {
                      selectedTutorType = "New Tutor";
                    });
                  },
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 18),
                    decoration: BoxDecoration(
                      color: selectedTutorType == "New Tutor"
                          ? const Color(0xFF1A2D56) // Selected color (Dark Blue)
                          : Colors.white, // Unselected color
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.black),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.3),
                          offset: const Offset(2, 2),
                          blurRadius: 3,
                        ),
                      ],
                    ),
                    child: Text(
                      "NEW TUTOR",
                      style: TextStyle(
                        color: selectedTutorType == "New Tutor"
                            ? Colors.white
                            : Colors.black,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Experience Input Field
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: TextField(
                controller: experienceController,
                decoration: InputDecoration(
                  hintText: "Enter Your Experience",
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1A2D56),
                padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 100),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              ),
              onPressed: () {

               
              },

              child: const Text("SIGN UP", style: TextStyle(color: Colors.white, fontSize: 16)),
            ),

            // Bottom Image
            Expanded(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Image.asset(
                    'assets/tut.png', // Replace with actual image path
                    height: 180,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
